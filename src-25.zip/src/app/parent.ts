export class Parent {
    parent_task: string;
}


