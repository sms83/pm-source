export class Project {
    project: string;
    start_date: Date;
    end_date: Date;
    priority: number;
    manager: string;
}
