export class Task {
    project: string;
    task: string;
    priority: number;   
    parent_task: string;
    start_date: any;
    end_date: any;
    user: string;
}


