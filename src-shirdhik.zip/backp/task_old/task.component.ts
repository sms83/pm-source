import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Project } from '../../project';
import { ProjectService } from '../../project.service';
import { User } from '../../user';
import { UserService } from '../../user.service';
import { Task } from '../../task';
import { TaskService } from '../../task.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../filter.pipe';
import { FindtasknamePipe } from '../../findtaskname.pipe'; 
import { Observable } from 'rxjs/Observable';
import {debounceTime, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  constructor(private router: Router, private flashMessagesService: FlashMessagesService, private taskService: TaskService,
    private location: Location) { }

    task = new Task();
    taskList: Task[];
   
  ngOnInit() {
      this.ngbdTypeaheadTemplate();
  }


  projectObj = new Project();
  projectList: Project[];
  search:any;
  formatter:any;
  selectedParent:{_id:string, first_name:string} = null;
  clickedItem:string;
  usersResult:{_id:string, first_name:string}[];

  
  ngbdTypeaheadTemplate() 
  {
    this.formatter = (x: {task: string}) => {
      console.log(x);
      return x.task;
    }; 
    this.search = (text$: Observable<string>) => text$
    .debounceTime(200)
    .distinctUntilChanged()
    .map(term => term === '' ? []
      : this.tasksResult.filter(tr => tr.task.toLowerCase().indexOf(term.toLowerCase()) > -1));
  }

  selectedItem(item){
    this.clickedItem=item.item._id;
    console.log('here we go');
    console.log(this.clickedItem);
  }


  addProject() {
    this.submitted = true;
   
     this.projectObj.start_date = new Date(this.projectObj.start_date);
     this.projectObj.start_date.toISOString().substring(0, 10);
 
     this.projectObj.end_date = new Date(this.projectObj.end_date);
     this.projectObj.end_date.toISOString().substring(0, 10);
 
    this.projectService.saveProject(this.projectObj).subscribe(
       success => {
       this.flashMessagesService.show('Project added succesfully', 
       { cssClass: 'alert-success', timeout: 3000 });
       this.router.navigate(['/project']);
       }, error => {
       this.flashMessagesService.show('Something went wrong', { cssClass: 'alert-danger', timeout: 3000 });
       }); 
  }  

 updateTask() {
  this.submitted = true;
  this.taskService.updateTask(this.getCheckID,this.task)
  .subscribe(()=> this.message = "Task Updated Successfully!");
}

deleteTask(id) {
  this.submitted = true;
  this.taskService.deleteTask(id)
  .subscribe(()=> this.message = "Task Deleted Successfully!");
}

 findbyID(id)
 { 
   this.getCheckID = id;
     this.taskService.getTasksById(id)
      .subscribe(task => this.task = task);
 }

 getTasks(val) 
 {
  this.sortval = val;
    if(this.sortval) 
    {
          return this.taskService.getSortedTasksList(this.sortval)
        .subscribe(
        taskList => {
        console.log(taskList);
        this.taskList = taskList;
        });
    }
    else
    {
        return this.taskService.getTasksList()
        .subscribe(
        taskList => {
        console.log(taskList);
        this.taskList = taskList;
        });
    }
}

}
