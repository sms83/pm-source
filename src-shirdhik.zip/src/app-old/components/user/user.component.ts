import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { User } from '../../user';
import { UserService } from '../../user.service';
import { Location } from '@angular/common';
import { FilterPipe } from '../../filter.pipe';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService: UserService,
    private location: Location) { }

    user = new User();
    submitted = false;
    sortval : any ;
    message: string;
    userList: User[];
    getCheckID  : any;

  ngOnInit() {
    this.getUsers(this.sortval);
  }

 adduser() {
   this.submitted = true;
   this.userService.saveUser(this.user)
   .subscribe(()=> this.message = "User Added Successfully!");
 }

 updateUser() {
  this.submitted = true;
  this.userService.updateUser(this.getCheckID,this.user)
  .subscribe(()=> this.message = "User Updated Successfully!");
}

deleteUser(id) {
  this.submitted = true;
  this.userService.deleteUser(id)
  .subscribe(()=> this.message = "User Deleted Successfully!");
}

 findbyID(id)
 { 
   this.getCheckID = id;
     this.userService.getUsersById(id)
      .subscribe(user => this.user = user);
 }

 getUsers(val) 
 {
  this.sortval = val;
    if(this.sortval) 
    {
          return this.userService.getSortedUsersList(this.sortval)
        .subscribe(
        userList => {
        console.log(userList);
        this.userList = userList;
        });
    }
    else
    {
        return this.userService.getUsersList()
        .subscribe(
        userList => {
        console.log(userList);
        this.userList = userList;
        });
    }
}

 
}
